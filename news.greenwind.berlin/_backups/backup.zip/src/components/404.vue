<template>
	<div class="wrapper">
    <h1>Page not found</h1>
	</div>
</template>

<script>
export default {
  name: 'homepage',
  data () {
    return {
    }
  }
}
</script>

<style lang="sass" scoped>
h1, h2
  font-weight: normal
a
  color: #42b983
</style>
